<?php
	include "db.php"; // подключение к базе данных
	
	$countView = (int)$_POST['count_add']; 	// количество записей, получаемых за один раз
	$startIndex = (int)$_POST['count_show']; // с какой записи начать выборку
	
	// запрос к бд
	$query = "SELECT * FROM `tbl_news` LIMIT $startIndex, $countView";
	$sql = mysqli_query($link, $query) or die(mysqli_error($link));
	$newsData = array();
	while($result = mysqli_fetch_assoc($sql)){
		$newsData[] = $result;
	}
	
	if(empty($newsData)){
		// если новостей нет
		echo json_encode(array(
			'result' 	=> 'finish'
		));
	}else{
		// если новости получили из базы, то свормируем html элементы
		// и отдадим их клиенту
		$html = "";
		foreach($newsData as $oneNews){
			$html .= "
				<div>
					<b>{$oneNews['title']}</b>
					<p>{$oneNews['small_text']}</p>
				</div>
			";
		}
		echo json_encode(array(
			'result' 	=> 'success',
			'html'		=> $html
		));
	}
	
	